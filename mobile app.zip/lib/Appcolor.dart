import 'dart:ui';

class Appcolor {
  static const PrimaryColor1 =  Color(0xFFFECE2F);

}